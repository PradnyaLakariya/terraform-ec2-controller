variable "aws_region" {
  type        = string
  description = "AWS deployment region"
  default     = "ap-south-1"
}

variable "instance_type" {
  type        = string
  description = "EC2 instance sizing"
  default     = "t3.micro"
}

variable "ssh_allowed_cidr" {
  type        = string
  description = "Public IPv4 address allowed to SSH, in CIDR notation"
}
