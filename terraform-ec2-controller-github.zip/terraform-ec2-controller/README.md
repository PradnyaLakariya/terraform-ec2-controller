# Terraform EC2 Controller & Nested Infrastructure Deployment

Terraform lab: provision an EC2 controller in AWS Mumbai (`ap-south-1`), install Terraform on it, and create an S3 bucket using a nested Terraform configuration.

## Files
- `main.tf` — provider, IAM role/profile, SSH key, security group, Ubuntu AMI, EC2 instance, bootstrap script.
- `variables.tf` — AWS region, instance type, allowed SSH CIDR.
- `outputs.tf` — EC2 public IP and SSH command.

## Prerequisites
- Terraform CLI and AWS CLI installed locally.
- Authenticate using an appropriately permissioned IAM identity; do not use AWS root credentials for routine deployments.
- Ensure your AWS account is active and permitted to create the resources.

## Deploy
Run in this directory:
```powershell
terraform fmt
terraform init
terraform validate
terraform plan
```
When prompted for `ssh_allowed_cidr`, enter your own current public IPv4 address with `/32` appended. Review the plan before running:
```powershell
terraform apply
```
Only confirm after checking the account, region, and planned resources.

## Connect and run nested Terraform
Use the `ssh_command` output to connect. On the EC2 instance:
```bash
terraform -version
cd ~/secondary-infra
terraform init
terraform validate
terraform plan
terraform apply
```
Review the nested plan before applying. When finished, destroy the nested S3 bucket:
```bash
terraform destroy
```
Exit the EC2 instance, then destroy the outer infrastructure from your local project folder:
```powershell
terraform destroy
```

## Security and cost notes
- SSH is restricted to the CIDR you provide; use your current IP with `/32`.
- The EC2 role attaches `AdministratorAccess` for lab convenience. This is overly broad and must be replaced with least-privilege permissions for real deployments.
- EC2, EBS, and other resources can incur charges. Destroy resources when finished.
- Never commit private keys, AWS credentials, `.tfstate` files, or secret files to GitHub.
