output "ec2_public_ip" {
  description = "Public IP address of the Terraform controller"
  value       = aws_instance.terraform_runner.public_ip
}

output "ssh_command" {
  description = "SSH command to connect to the controller"
  value       = "ssh -i tf-runner-key.pem ubuntu@${aws_instance.terraform_runner.public_ip}"
}
